package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import edu.sjsu.yazdankhah.crypto.util.PassUtil;

/**
 * Model
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class Model {
	
	// Text file names
	final static String masterAccountsFilePath = "masterAccounts.txt";
	final static String websiteAccountsFilePath = "websiteAccounts.txt";
	final static String websiteAccountsTempFilePath = "websiteAccountsTemp.txt";
	final static String websiteAccountsOldFilePath = "websiteAccountsOld.txt";

	
	static Scanner s;
	private static MasterAccount loggedInAccount;
	private static MasterAccount signUpAccount;
	
	// Encryption/Decryption utility class.
	private static PassUtil passUtil = new PassUtil();
	
	private static String urlForEditing;
	
	private boolean shouldAlert = false;
	
	public boolean shouldAlert() {
		return shouldAlert;
	}

	public void setShouldAlert(boolean shouldAlert) {
		this.shouldAlert = shouldAlert;
	}

	// Creates a model with a logged in account and sign up account.
	public Model () {
		this.loggedInAccount = new MasterAccount();
		this.signUpAccount = new MasterAccount();
	}
	
	// Saves the master account name password and email
	public void saveMasterAccount(String name, String password, String email) {
		System.out.println(": : SAVING MASTER ACCOUNT : :");
		Model.signUpAccount.setUserName(name);
		Model.signUpAccount.setPassword(password);
		Model.signUpAccount.setEmail(email);
	}
	
	// Saves the master account secuirty question and answer.
	public void saveMasterSecurity(String question, String answer) {
		System.out.println(": : SAVING MASTER SECURITY QUESTION/ANSWER : :");
		Model.signUpAccount.setSecurityQuestion(question);
		Model.signUpAccount.setSecurityAnswer(answer);
	}
	
	// Creates a master account.
	public void createAccount() {
		System.out.println(": : CREATING MASTER ACCOUNT : :");
		try {
			
			//Creating buffers
			FileWriter fw = new FileWriter(masterAccountsFilePath, true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			
			//Writes new account to the master account file.
			// Encrypt password when putting it into files.
			pw.println(signUpAccount.getUserName()+","+passUtil.encrypt(signUpAccount.getPassword())+","+signUpAccount.getEmail());
			// Encrypt answer when putting it into files.
			pw.println(signUpAccount.getSecurityQuestion()+","+passUtil.encrypt(signUpAccount.getSecurityAnswer()));	// Store security and answer for logging in
			pw.println("END");					// Ensures that the database visually separates accounts
			pw.flush();
			pw.close();
			
		} catch (Exception E){
			System.out.println(": : CREATING MASTER ACCOUNT FAILED : :" + E.getMessage());
		}
		
		signUpAccount = null;
	}
	
	// Checks if an account exists.
	public boolean doesAccountExist(String user, String email) {
		System.out.println(": : CHECKING IF ACCOUNT ALREADY EXISTS: :");
		try {
			s = new Scanner(new File(masterAccountsFilePath));
			while(s.hasNextLine()) {
				String databaseAccountInfo = s.nextLine();				// This should equal to user, password, email
				String databaseSecurityAccountInfo = s.nextLine();		// This should equal to question, answer
				String endOfDatabaseAccount = s.nextLine();				// This should equal to "END"
				
				// Ensures that data is not corrupt
				if (!endOfDatabaseAccount.equals("END"))
					throw new Exception(": : DATABASE ERROR: USERNAME AND PASSWORD UNALIGNED. PLEASE CHECK DATABASE FILE: :");
				
				
				// Get username and password from databaseAccountInfo
				String[] splitAccountInfo = databaseAccountInfo.split(",");
				String databaseUsername = splitAccountInfo[0];
				String databaseEmail = splitAccountInfo[2];
						
				// Check if username/email already exists in database
				if (user.equals(databaseUsername) || user.equals(databaseEmail))
					return true;
			}
			
		} catch (Exception E){
			System.out.println(": : ACCOUNT CHECKING FAILED: : " + E.getMessage());
			E.printStackTrace();
		}
		
		System.out.println("ACCOUNT ALREADY EXISTS");
		return false;
	}
	
	// Correct format of each account in database
	// 1) ACCOUNT INFO
	// 2) SECURITY ACCOUNT INFO
	// 3) END
	
	// This also logs the user into the model
	public boolean isMasterAccountValid(String username, String password) {
		System.out.println(": : VERIFYING MASTER ACCOUNT : :");
		try {
			s = new Scanner(new File(masterAccountsFilePath));
			while(s.hasNextLine()) {
				String databaseAccountInfo = s.nextLine();
				String databaseSecurityAccountInfo = s.nextLine();
				String endOfDatabaseAccount = s.nextLine();				// This should equal to "END"
				
				// Ensures that data is not corrupt
				if (!endOfDatabaseAccount.equals("END"))
					throw new Exception(": : DATABASE ERROR: USERNAME AND PASSWORD UNALIGNED. PLEASE CHECK DATABASE FILE: :");
				
				
				// Get username and password from databaseAccountInfo
				String[] splitAccountInfo = databaseAccountInfo.split(",");
				String[] splitSecurityAccountInfo = databaseSecurityAccountInfo.split(",");
				String databaseUsername = splitAccountInfo[0];
				// Decrypt password when retieving it from files.
				String databasePassword = passUtil.decrypt(splitAccountInfo[1]);
				String databaseEmail = splitAccountInfo[2];
				String databaseQuestion = splitSecurityAccountInfo[0];
				// Decrypt answer when retieving it from files.
				String databaseAnswer = passUtil.decrypt(splitSecurityAccountInfo[1]);
				
				// Account match found
				if (databaseUsername.equals(username) && databasePassword.equals(password)) {
					this.logIn(databaseUsername, databasePassword, databaseEmail, databaseQuestion, databaseAnswer);
					return true;
				}
			}
			
		} catch (Exception E){
			System.out.println(": : VERIFYING MASTER ACCOUNT FAILED : : " + E.getMessage());
			E.printStackTrace();
		}
		
		System.out.println("INVALID MASTER ACCOUNT");
		return false;
	}
	
	// Logs the account into the system
	private void logIn(String username,String password,String email,String question,String answer) {

		loggedInAccount = new MasterAccount(username, password, email, question, answer);
		ArrayList<Website> websites = fetchWebsites();
		loggedInAccount.setWebsites(websites);;
	}
	
	// fetches websites associated with account from the database file
	private ArrayList<Website> fetchWebsites() {
		ArrayList<Website> websites = new ArrayList<Website>();
		
		try {
			s = new Scanner(new File(websiteAccountsFilePath));
			while(s.hasNextLine()) {
				String[] splitWebsiteInfo = s.nextLine().split(",");
				
				// Line information
				String user = splitWebsiteInfo[0];
				String url = splitWebsiteInfo[1];
				String username = splitWebsiteInfo[2];
				// Decrypt password when retieving it from files.
				String password = passUtil.decrypt(splitWebsiteInfo[3]);
				String creationDate = splitWebsiteInfo[4];
				String expirationDate = splitWebsiteInfo[5];
				
				// If this line of info belongs to the logged in account, then
				if (user.equals(Model.loggedInAccount.getUserName())) 
					websites.add(new Website(url, username, password, Long.parseLong(creationDate), Long.parseLong(expirationDate)));
				
			}
			s.close();
		} catch (Exception E){
			System.out.println(": : FETCHING WEBSITES FAILED : : " + E.getMessage());
			E.printStackTrace();
		}
		
		return websites;
	}
	
	// Log account out of system
	public void logOut() {
		loggedInAccount = null;
	}
	
	// Updates password in the database
	public void updatePassword(String newPassword) {
		System.out.println(": : UPDATING PASSWORD : :");
		
		/* Implementation:
		 * Read through all lines in file and store it into a string object
		 * Use replaceAll() to search through string and replace string's password w/ new password
		 * Rewrite the string back to the file
		 * */
		
		
		// STEP 1) READ FILE
		String oldContent = "";
		try {
			s = new Scanner(new File(masterAccountsFilePath));
			while(s.hasNextLine()) {
				oldContent = oldContent + s.nextLine() + System.lineSeparator();
			}
			s.close();
		} catch (Exception E){
			System.out.println(": : UPDATE PASSWORD FAILED - STEP 1) READ FILE : : " + E.getMessage());
			E.printStackTrace();
		}
		
		
		// STEP 2) REPLACE OLD PASSWORD w/ NEW PASSWORD
		// Find the account to be modified in the string
		String username = this.loggedInAccount.getUserName();
		String password = this.loggedInAccount.getPassword();
		String email = this.loggedInAccount.getEmail();
		
		// Replace the account's password w/ a new password in the string
		String findThisString = username + "," + passUtil.encrypt(password) + "," + email;
		// Encrypt password when putting it into files.
		String replacementString = username + "," + passUtil.encrypt(newPassword) + "," + email;
		String newContent = oldContent.replace(findThisString, replacementString);
		
		
		// STEP3) REWRITE STRING BACK TO DATABASE
		// newContent contains the fully updated database. Write it back to the database file.
		try {
			FileWriter fw = new FileWriter(masterAccountsFilePath);
			fw.write(newContent);
			
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		// Finally, log out
		this.logOut();
	}
	
	// Add website to each individual master user
	public void addWebsite(String url, String username, String password, long creationDate, long expirationDate) {
		
		String masterUsername = this.loggedInAccount.getUserName();
		try {
			
			FileWriter fw = new FileWriter(websiteAccountsFilePath, true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bw);
			
			// Encrypt password when putting it into files.
			pw.println(masterUsername+ "," + url+","+username+","+passUtil.encrypt(password) + "," + creationDate + "," + expirationDate);
			pw.flush();
			pw.close();
			bw.close();
			fw.close();
			
		} catch (Exception E){
			System.out.println(": : ADDING WEBSITE FAILED : :" + E.getMessage());
		}
		
		Model.loggedInAccount.setWebsites(fetchWebsites());
	}
	
	// Delete website from files.
	public void deleteWebsite(String url) {
		
		String masterUsername = this.loggedInAccount.getUserName();
		
		try {
			
			File inputFile = new File(websiteAccountsFilePath);
			File tempFile = new File(websiteAccountsTempFilePath);

			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

			String lineToRemove = masterUsername + "," + url;
			String currentLine;

			while((currentLine = reader.readLine()) != null) {
			    // trim newline when comparing with lineToRemove
			    String trimmedLine = currentLine.trim();
			    if(trimmedLine.startsWith(lineToRemove)) continue;
			    writer.write(currentLine + System.getProperty("line.separator"));
			}
			writer.close(); 
			reader.close();
			File oldFile = new File(websiteAccountsOldFilePath);
			if (oldFile.exists()) {
				oldFile.delete();
			}
			boolean successful = inputFile.renameTo(new File(websiteAccountsOldFilePath));
			if(!successful) {
				System.out.println(" RENAME websiteAccountsFile to websiteAccountsOldFile FAILED ");
			}
			successful = tempFile.renameTo(new File(websiteAccountsFilePath));
			if(!successful) {
				System.out.println(" RENAME websiteAccountsTempFile to websiteAccountsFile FAILED ");
			}
			if (oldFile.exists()) {
				oldFile.delete();
			}
		} catch (Exception E){
			System.out.println(": : DELETING WEBSITE FAILED : :" + E.getMessage());
		}
		
		Model.loggedInAccount.setWebsites(fetchWebsites());
	}

	
	public MasterAccount getMasterAccount() {
		return this.loggedInAccount;
	}
	
	public ArrayList<Website> getWebsites() {
		return this.loggedInAccount.getWebsites();
	}
	
	// Check to see if a website already exists for a particular user.
	public boolean doesWebsiteExist(String givenURL) {
		try {
			s = new Scanner(new File(websiteAccountsFilePath));
			while(s.hasNextLine()) {
				String[] splitWebsiteInfo = s.nextLine().split(",");
				
				// Line information
				String user = splitWebsiteInfo[0];
				String url = splitWebsiteInfo[1];
				
				// check if the url matches with the url in the database
				if (givenURL.equals(url) && user.equals(Model.loggedInAccount.getUserName())) {
					return true;
				}
			}
			s.close();
			return false;
		} catch (Exception E){
			System.out.println(": : ERROR IN VERIFYING WEBSITE : : " + E.getMessage());
			E.printStackTrace();
		}
		return false;
	}
	
	// get password based on the url given
	public static String getWebsitePassword(String givenURL) {
		// STEP 1) READ FILE
		try {
			s = new Scanner(new File(websiteAccountsFilePath));
			while(s.hasNextLine()) {
				String[] splitWebsiteInfo = s.nextLine().split(",");
				
				// Line information
				String user = splitWebsiteInfo[0];
				String url = splitWebsiteInfo[1];
				String username = splitWebsiteInfo[2];
				// Decrypt password when retieving it from files.
				String password = passUtil.decrypt(splitWebsiteInfo[3]);
				
				// check if the url matches with the url in the database
				if (givenURL.equals(url) && user.equals(Model.loggedInAccount.getUserName())) {
					return password;
				}
			}
			s.close();
			
			throw new Exception(": : ERROR: EXPECTED TO GET A PASSWORD VALUE IN THE DATABASE : :");

		} catch (Exception E){
			System.out.println(": : ERROR IN GET WEBSITE PASSWORD : : " + E.getMessage());
			E.printStackTrace();
		}
		
		return null;
	}
	
	public String longToDate(long l) {
		Date d = new Date(l);
		return d.toString();
	}
	
	public long longDifferenceInDays(long end, long beginning) {
		return TimeUnit.MILLISECONDS.toDays(end - beginning)+1;
	}

	// Get list of expired websites
	public ArrayList<Website> getExpiredWebsites() {
		ArrayList<Website> expiredWebsites = new ArrayList<Website>();
		
		for (Website w: this.loggedInAccount.getWebsites()) {
			Date expirationDate = new Date(w.getExpirationDate());
			
			// if the expiration date has passed, then add it to the expiredWebsites list
			if (expirationDate.before(new Date())) {
				expiredWebsites.add(w);
			}
		}
		
		return expiredWebsites;
	}
	
	// Set the url that will be edited
	public void setEditURL(String url) {
		urlForEditing = url;
	}
	
	// Get the information for the website the user wants to edit.
	public String[] getEditURL() {
		try {
			s = new Scanner(new File(websiteAccountsFilePath));
			while(s.hasNextLine()) {
				String[] splitWebsiteInfo = s.nextLine().split(",");
				
				// Line information
				String user = splitWebsiteInfo[0];
				String url = splitWebsiteInfo[1];
				String username = splitWebsiteInfo[2];
				// Decrypt password when retieving it from files.
				String password = passUtil.decrypt(splitWebsiteInfo[3]);
				String creationDate = splitWebsiteInfo[4];
				String expirationDate = splitWebsiteInfo[5];
				
				// If this line of info belongs to the logged in account, then
		
				// check if the url matches with the url in the database
				if (urlForEditing.equals(url) && user.equals(Model.loggedInAccount.getUserName())) {
					String[] data = new String[5];
					data[0] = urlForEditing;
					data[1] = username;
					Date now = new Date();
					long nowTime = now.getTime();
					data[2] = String.valueOf(longDifferenceInDays(Long.parseLong(expirationDate), nowTime));
					data[3] = password;
					return data;
					
				}
			}
			s.close();
			
			throw new Exception(": : ERROR: EXPECTED TO GET A URL INFORMATION FROM THE DATABASE : :");

		} catch (Exception E){
			System.out.println(": : ERROR IN GET WEBSITE DATA : : " + E.getMessage());
			E.printStackTrace();
		}
		
		return null;
	}
	
}
