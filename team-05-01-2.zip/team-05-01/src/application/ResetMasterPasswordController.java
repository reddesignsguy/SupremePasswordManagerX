package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * Controller for the reset master password screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class ResetMasterPasswordController extends Controller{
	
	
	@FXML
	private TextField newPassword;
	
	@FXML
	private Button saveButton;
	
	// save password
	public void save(ActionEvent event) throws IOException{
		// check that user has entered password
		if (newPassword.getText().length() == 0) {
			this.alert("Warning", "You must enter a password");
			return;
		}
		
		// successful password, save it
		Controller.model.updatePassword(newPassword.getText());
		this.switchScene(event, "signIn.fxml");
		
	}
	
	/** 
	* On back event go back to the lock page.
	* 
	* @param event the back event
	*/
	public void back(ActionEvent event) throws IOException{
		super.switchScene(event, "home.fxml");
	}

}
