package application;

import java.util.Random;

/**
 * Password generator object the generates random passwords.
 * 
 * @author alan viollier, Albany Patriawan, Choyee Chan Myae
 */
public class PasswordGenerator {
	private int maxLength;
	private int minLength;
	private boolean specialCharacters;
	private boolean capitalLetters;
	private Random random = new Random();
	
	private final char[] possibleCharacters = "abcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
	private final char[] possibleCharactersSpecial = "abcdefghijklmnopqrstuvwxyz0123456789!\"#$%&'()*+-./:;<=>?@[\\]^_`{|}~".toCharArray();
	private final char[] possibleCharactersCapital = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
	private final char[] possibleCharactersSpecialCapital = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!\"#$%&'()*+-./:;<=>?@[\\]^_`{|}~".toCharArray();
	
	/** 
	* Class constructor with no input with base values.
	* 
	*/
	public PasswordGenerator() {
		this.maxLength = 22;
		this.minLength = 20;
		this.specialCharacters = true;
		this.capitalLetters = true;
	}
	
	/** 
	* Class constructor specifying the max length and minimum length for the password generation.
	* 
	* @param maxLength maximum length for the password
	* @param minLength minimum length for the password
	*/
	public PasswordGenerator(int maxLength, int minLength) {
		this.maxLength = maxLength;
		this.minLength = minLength;
		this.specialCharacters = true;
		this.capitalLetters = true;
	}
	
	/** 
	* Class constructor specifying the max length, minimum length, and if there are special and capital letters for the password generation.
	* 
	* @param maxLength maximum length for the password
	* @param minLength minimum length for the password
	* @param specialCharacters boolean value for if there should be special characters
	* @param capitalLetters boolean value for if there should be special characters
	*/
	public PasswordGenerator(int maxLength, int minLength, boolean specialCharacters, boolean capitalLetters) {
		this.maxLength = maxLength;
		this.minLength = minLength;
		this.specialCharacters = specialCharacters;
		this.capitalLetters = capitalLetters;
	}
	
	/**
	 * Generates a password based on all the previoud inputs and returns it as a string.
	 * 
	 * @return the randomly generator password
	 */
	public String generatePassword() {
		int passwordLength = random.nextInt(maxLength - minLength + 1) + minLength;
		char[] password = new char[passwordLength];
		for(int i = 0; i < passwordLength; i++) {
			char current;
			if(specialCharacters) {
				if(capitalLetters) {
					current = possibleCharactersSpecialCapital[random.nextInt(possibleCharactersSpecialCapital.length)];
				}
				else {
					current = possibleCharactersSpecial[random.nextInt(possibleCharactersSpecial.length)];
				}
				
			}
			else if(capitalLetters) {
				current = possibleCharactersCapital[random.nextInt(possibleCharactersCapital.length)];
			}
			else {
				current = possibleCharacters[random.nextInt(possibleCharacters.length)];
			}
			password[i] = current;
		}		
		return new String(password);
	}
	
	
}
