package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

// Controller abstract class for implementing controllers.
public abstract class Controller {
	
	public static Model model = new Model();
	
	public void switchScene(ActionEvent event, String s) throws IOException {
		Parent homePage = FXMLLoader.load(getClass().getResource(s));
		Scene homePageScene = new Scene(homePage);
		Stage stg = (Stage) ((Node) event.getSource()).getScene().getWindow();
		
		stg.setScene(homePageScene);
		stg.show();
	}
	
	public void alert(String title, String content) {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setTitle(title);		
		alert.setContentText(content);
		alert.showAndWait();
	}

}
