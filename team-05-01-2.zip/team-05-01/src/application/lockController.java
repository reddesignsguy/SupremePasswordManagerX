package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

/**
 * Controller for the Lock screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class lockController extends Controller {
	
	@FXML
	private Button signUpButton;
	
	@FXML
	private Button signInButton;
	
	
	/** 
	* On signUp event go to the sign up page.
	* 
	* @param event the signUp event
	*/
	public void signUp(ActionEvent event) throws IOException {
		super.switchScene(event, "signUp.fxml");
	}
	
	/** 
	* On signIn event go to the sign in page.
	* 
	* @param event the singIn event
	*/
	public void signIn(ActionEvent event) throws IOException {
		super.switchScene(event, "signIn.fxml");
	}

}
