package application;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * Controller for the add website screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class AddWebsiteController extends Controller{
	
	
	@FXML
	private TextField url;
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField days;
	
	@FXML
	private TextField password;

	// Auto generate password
	public void autoGenerate(ActionEvent event) throws IOException{
		PasswordGenerator generate = new PasswordGenerator();
		password.setText(generate.generatePassword());
	}
	
	// Saves the new information
	public void save(ActionEvent event) throws IOException{
		
		// User must enter all fields and auto generate a password
		if (url.getText().length() == 0 || username.getText().length() == 0 || days.getText().length() == 0 || password.getText().length()==0) {
			this.alert("Warning", "You must enter all fields first and generate a new password");
			return;
		}
		if(Controller.model.doesWebsiteExist(url.getText())) {
			this.alert("Warning", "You already have this website URL used.");
			return;
		}
		
		// Get right now's date for creation date
		Date initialDate = new Date();
		long nowTime = initialDate.getTime();
		
		// Get the date variable days from now for expiration date
		Calendar c= Calendar.getInstance();
		c.add(Calendar.DATE, Integer.parseInt(days.getText()));
		Date expiredDate = c.getTime();
		long expiredTime = expiredDate.getTime();
		
		
		Controller.model.addWebsite(url.getText(), username.getText(), password.getText(), nowTime, expiredTime);
		this.switchScene(event, "home.fxml");
	}
	
	/** 
	* On back event go back to the lock page.
	* 
	* @param event the back event
	*/
	public void back(ActionEvent event) throws IOException{
		super.switchScene(event, "home.fxml");
	}


}
