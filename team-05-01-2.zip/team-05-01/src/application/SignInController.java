package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * Controller for the sign in screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class SignInController extends Controller {
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField password;
	
	@FXML
	private Button signInButton;
	
	/** 
	* On signIn event go to the home page.
	* 
	* @param event the signIn event
	*/
	public void signIn(ActionEvent event) throws IOException{        
        
        // If master account is valid then go to the home page, otherwise it is invalid
        if (Controller.model.isMasterAccountValid(username.getText(), password.getText())) {
            System.out.println("VALID");
            Controller.model.setShouldAlert(true);
            super.switchScene(event, "home.fxml");
        } else {
            this.alert("Invalid Username or Password", "Invalid Username or Password");
            System.out.println("INVALID");
        }
        
    }
	
	/** 
	* On back event go back to the lock page.
	* 
	* @param event the back event
	*/
	public void back(ActionEvent event) throws IOException{
		super.switchScene(event, "lock.fxml");
	}
	
	
}
