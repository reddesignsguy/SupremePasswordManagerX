package application;

import java.io.IOException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * Controller for the reset master password check screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class ResetMasterPasswordCheckController extends Controller implements Initializable {
	
	
	MasterAccount masterAccount = Controller.model.getMasterAccount();
	
	@FXML
	private Text question;
	
	@FXML
	private TextField answer;
	
	//Inizialize by adding the question to the screen
	@Override
	public void initialize(java.net.URL arg0, ResourceBundle arg1) {
		System.out.println("INTIIALIZNIG");
		question.setText(Controller.model.getMasterAccount().getSecurityQuestion());
	}
	
	// If the password is correct move on.
	public void next(ActionEvent event) throws IOException{
		System.out.println(masterAccount.getSecurityAnswer());
		System.out.println(answer.getText());
		if (answer.getText().equals(masterAccount.getSecurityAnswer())) {
			System.out.println("correct answer");
			this.switchScene(event, "resetMasterPassword.fxml");
		} else {
			this.alert("Warning", "Incorrect answer");
			System.out.println("invalid answer");
		}
	}
	
	/** 
	* On back event go back to the lock page.
	* 
	* @param event the back event
	*/
	public void back(ActionEvent event) throws IOException{
		super.switchScene(event, "home.fxml");
	}


}
