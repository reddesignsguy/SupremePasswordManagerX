package application;

import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * Controller for the edit website screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class EditController extends Controller implements Initializable {
	
	
	@FXML
	private Text url;
	
	@FXML
	private TextField username;
	
	@FXML
	private TextField days;
	
	@FXML
	private TextField password;

	/** 
	* On initialization load the website information.
	* 
	* @param arg0 url
	* @param arg1 resource
	*/
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		String[] data = Controller.model.getEditURL();
		
		url.setText(data[0]);
		username.setText(data[1]);
		days.setText(data[2]);
		password.setText(data[3]);

	}
	
	// Auto generate password
	public void autoGenerate(ActionEvent event) throws IOException{
		PasswordGenerator generate = new PasswordGenerator();
		password.setText(generate.generatePassword());
	}
	
	public void save(ActionEvent event) throws IOException{
		
		// User must enter all fields and auto generate a password
		if (url.getText().length() == 0 || username.getText().length() == 0 || days.getText().length() == 0 || password.getText().length()==0) {
			this.alert("Warning", "You must enter all fields first and generate a new password");
			return;
		}
		
		// Get right now's date for creation date
		Date initialDate = new Date();
		long nowTime = initialDate.getTime();
		
		// Get the date variable days from now for expiration date
		Calendar c= Calendar.getInstance();
		c.add(Calendar.DATE, Integer.parseInt(days.getText()));
		Date expiredDate = c.getTime();
		long expiredTime = expiredDate.getTime();
		
		Controller.model.deleteWebsite(url.getText());
		Controller.model.addWebsite(url.getText(), username.getText(), password.getText(), nowTime, expiredTime);
		
		super.switchScene(event, "home.fxml");
	}
	
	/** 
	* On back event go back to the lock page.
	* 
	* @param event the back event
	*/
	public void back(ActionEvent event) throws IOException{
		super.switchScene(event, "home.fxml");
	}
}


