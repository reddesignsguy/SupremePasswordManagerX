package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

/**
 * Starter class Main.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class Main extends Application {
	
	private static Stage stg;
	private final static int WIDTH = 527;
	private final static int HEIGHT = 527;
	
	/** 
	* Starts the program by setting up the scene.
	* 
	* @param primaryStage the primary stage
	*/
	@Override
	public void start(Stage primaryStage) {
		try {
			stg = primaryStage;
			stg.setWidth(WIDTH);
			stg.setHeight(HEIGHT);
			AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("lock.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Supreme Password Manager X");
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/** 
	* Changes from one scene to another.
	* 
	* @param fxml the other scene to change to
	*/
	public void changeScene(String fxml) throws IOException {
		Parent pane = FXMLLoader.load(getClass().getResource(fxml));
		stg.getScene().setRoot(pane);
	}
	
	/** 
	* Main method.
	* 
	* @param args arguments
	*/
	public static void main(String[] args) {
		launch(args);
	}
}
