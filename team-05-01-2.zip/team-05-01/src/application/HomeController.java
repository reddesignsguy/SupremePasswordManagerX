package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 * Controller for the home screen.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class HomeController extends Controller implements Initializable {

	@FXML
	private TextField username;

	@FXML
	private TextField password;

	@FXML
	private Button resetMasterPasswordButton;

	@FXML
	private TextField searchBar;
	
	@FXML
	private ListView<HBox> listView;

	@FXML
	private VBox websites;

	/** 
	* On initialization load the website.
	* 
	* @param arg0 url
	* @param arg1 resource
	*/
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

        // Remove any template websites that might appear from SceneBuilder
        websites.getChildren().clear(); 

        // Load account's websites into homepage
        ArrayList<Website> accountWebsites = Controller.model.getWebsites();
        String str = "";
        for (int i = 0; i < accountWebsites.size(); i++) {
            String url = accountWebsites.get(i).getUrl(); // current url
            HBox newWebsiteSection = newWebsiteSection(url); // create a new website section w/ fetched url
            websites.getChildren().add(newWebsiteSection); // add new website section to homepage
        }

        // Alert user of expired dates
        ArrayList<Website> expiredWebsites = Controller.model.getExpiredWebsites(); // Get list of expired websites

        /*
         * Alert user of expired websites only if there are expired websites
         */
        if (Controller.model.shouldAlert() && expiredWebsites.size() > 0) {
            // Lay out expired websites and their expiration dates onto an alert window
            for (int i = 0; i < expiredWebsites.size(); i++) {
                String url = expiredWebsites.get(i).getUrl();
                String date = Controller.model.longToDate(expiredWebsites.get(i).getExpirationDate());
                str = str + url + " expired on " + date + "\n";
            }

            this.alert("Expired dates", str);
        }
        Controller.model.setShouldAlert(false);
    }

	// Returns a new website section to be displayed on the homepage
	private HBox newWebsiteSection(String url) {
		// Create nodes
		HBox template = new HBox();
		HBox left = new HBox();
		HBox right = new HBox();

		Text urlBox = new Text();
		urlBox.setFont(new Font("Avenir Next Bold", 20));
		Button copyButton = newButton("COPY");
		copyButton.setFont(new Font("Avenir Next Bold", 12));
		Button editButton = newButton("EDIT");
		editButton.setFont(new Font("Avenir Next Bold", 12));
		Button deleteButton = newButton("DELETE");
		deleteButton.setFont(new Font("Avenir Next Bold", 12));

		// Link up nodes
		template.getChildren().add(left);
		template.getChildren().add(right);

		left.getChildren().add(urlBox);

		right.getChildren().add(copyButton);
		right.getChildren().add(editButton);
		right.getChildren().add(deleteButton);

		// Set properties
		copyButton.setOnAction((e) -> {
			ClipboardContent content = new ClipboardContent();
			String password = Model.getWebsitePassword(url);

			//System.out.println("Copied password: " + password);
			content.putString(password);

			Clipboard.getSystemClipboard().setContent(content);
		});
		editButton.setOnAction((e) -> edit(e, url));
		deleteButton.setOnAction((e) -> delete(e, url));

		left.setPrefWidth(280);

		right.setAlignment(Pos.CENTER_RIGHT);

		urlBox.setText(url);

		return template;
	}

	// Eeturns a button with the specified text.
	private Button newButton(String text) {
		Button b = new Button();
		b.setText(text);
		b.setOnAction((event) -> {
		});
		return b;
	}

	// Go to addwebsite panel.
	public void addWebsite(ActionEvent e) throws IOException {
		super.switchScene(e, "addWebsite.fxml");
	}
	
	// Go back to sign in page.
	public void backToSignIn(ActionEvent e) throws IOException {
		super.switchScene(e, "signIn.fxml");
	}
	
	// Search for website.
	public void search(KeyEvent e) throws IOException {
		websites.getChildren().clear();

		// Load account's websites into homepage
		ArrayList<Website> accountWebsites = Controller.model.getWebsites();
		for (int i = 0; i < accountWebsites.size(); i++) {
			String url = accountWebsites.get(i).getUrl(); // current url
			String searchTerm = searchBar.getText();
			if (!e.isShortcutDown() && !e.isAltDown() && !e.isControlDown() && !e.isMetaDown()) {
				searchTerm = searchTerm + e.getCharacter();
			}
			searchTerm = searchTerm.replaceAll("[^a-zA-Z0-9.:/-]", "");
			searchTerm = searchTerm.toLowerCase();
			//System.out.println("seraching for " + searchTerm);
			if(!url.toLowerCase().contains(searchTerm)) {
				continue;
			}
			HBox newWebsiteSection = newWebsiteSection(url); // create a new website section w/ fetched url
			websites.getChildren().add(newWebsiteSection); // add new website section to homepage
		}
		
	}

	// Deletes the website.
	private void delete(ActionEvent e, String url) {
		System.out.println("DELETING " + url);
		try {
			Controller.model.deleteWebsite(url);
			super.switchScene(e, "home.fxml");
		} catch (IOException ex) {
			System.out.println("Error deleting: " + ex);
		}
	}
	
	private void edit(ActionEvent e, String url) {
		System.out.println("EDITING " + url);
		try {
			Controller.model.setEditURL(url);
			super.switchScene(e, "edit.fxml");
		} catch (IOException ex) {
			System.out.println("Error editing: " + ex);
		}
	}

	// Go to reset master password page.
	public void resetMasterPassword(ActionEvent e) throws IOException {
		super.switchScene(e, "resetMasterPasswordCheck.fxml");
	}

}
