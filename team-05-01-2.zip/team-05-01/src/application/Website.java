package application;

/**
 * Website object.
 * 
 * @author alan viollier, albany patriawan, choyee chan myae
 */
public class Website {
	private String url;
	private String username;
	private String password;
	private long creationDate;
	private long expirationDate;
	
	// Creates website object with url, username, password, creationdate, and expiration date.
	public Website(String url, String username, String password, long creationDate, long expirationDate) {
		this.setUrl(url);
		this.setUsername(username);
		this.setPassword(password);
		this.setCreationDate(creationDate);
		this.setExpirationDate(expirationDate);
	}

	// Getters and Setters
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(long creationDate) {
		this.creationDate = creationDate;
	}

	public long getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(long expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	
}
